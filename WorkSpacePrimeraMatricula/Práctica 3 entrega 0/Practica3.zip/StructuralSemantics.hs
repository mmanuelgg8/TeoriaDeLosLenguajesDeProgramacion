{-|

Programming Languages
Fall 2020

Implementation in Haskell of the Structural Operational Semantics
described in Chapter 2 of Nielson & Nielson, Semantics with Applications

Author:

-}

module StructuralSemantics where

import           While

-- representation of configurations for While

data Config = Inter Stm State  -- <S, s>
            | Final State      -- s
            | Stuck Stm State  -- <S, s>

isFinal :: Config -> Bool
isFinal (Inter ss s) = False
isFinal (Final s)    = True

isInter :: Config -> Bool
isInter (Inter _ _) = True
isInter _           = False

isStuck :: Config -> Bool
isStuck (Stuck _ _) = True
isStuck _           = False

-- representation of the transition relation <S, s> -> s'

sosStm :: Config -> Config

-- x := a

sosStm (Inter (Ass x a) s) = Final (update s x (aVal a s))
  where
    update s x v y = if x == y then v else s y

-- skip

-- todo

-- s1; s2

-- todo

-- if b then s1 else s2

-- todo

-- while b do s

-- todo

-- repeat s until b

-- todo

-- for x a1 to a2 s

-- todo

-- abort

-- todo
